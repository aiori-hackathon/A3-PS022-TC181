// SPDX-License-Identifier: GPL-2.0
#include <linux/bpf.h>
#include <linux/if_ether.h>

#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/in.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>

#define DNS_PORT 53
#define SCALE 1000000000ULL
#define MAX_NAME_WIRE 255
#define MAX_RATE 100000U
#define MAX_BURST 100000U

struct vlan_tag { __be16 tci, encapsulated_proto; };
struct dns_hdr { __be16 id, flags, qd, an, ns, ar; };
struct bucket { struct bpf_spin_lock lock; __u32 pad; __u64 last_ns; __u64 tokens; };
struct settings { __u32 per_rate, per_burst, global_rate, global_burst; };
enum { SEEN, DNS_PASS, NON_DNS_PASS, DROP_SOURCE, DROP_GLOBAL, DROP_MALFORMED, PASS_FRAGMENT, MAP_FAILURE, NUM_STATS };

struct { __uint(type, BPF_MAP_TYPE_LRU_HASH); __uint(max_entries, 16384); __type(key, __u32); __type(value, struct bucket); } sources SEC(".maps");
struct { __uint(type, BPF_MAP_TYPE_ARRAY); __uint(max_entries, 1); __type(key, __u32); __type(value, struct bucket); } global_bucket SEC(".maps");
struct { __uint(type, BPF_MAP_TYPE_ARRAY); __uint(max_entries, 1); __type(key, __u32); __type(value, struct settings); } config SEC(".maps");
struct { __uint(type, BPF_MAP_TYPE_PERCPU_ARRAY); __uint(max_entries, NUM_STATS); __type(key, __u32); __type(value, __u64); } stats SEC(".maps");

static __always_inline void count(__u32 index) { __u64 *v = bpf_map_lookup_elem(&stats, &index); if (v) (*v)++; }
static __always_inline int allow(struct bucket *b, __u32 rate, __u32 burst, __u64 now) {
    int ok = 0;
    bpf_spin_lock(&b->lock);
    if (!b->last_ns) { b->tokens = (__u64)burst * SCALE; b->last_ns = now; }
    if (now > b->last_ns) {
        __u64 delta = now - b->last_ns;
        // Refill correctly after arbitrarily long idle periods without overflow.
        // A full bucket needs at most ceil(burst / rate) seconds to refill.
        __u64 cap = (__u64)burst * SCALE;
        __u64 missing = cap - (b->tokens > cap ? cap : b->tokens);
        __u64 enough_ns = missing / rate + (missing % rate != 0);
        if (delta >= enough_ns) b->tokens = cap;
        else b->tokens += delta * rate;
        b->last_ns = now;
    }
    if (b->tokens >= SCALE) { b->tokens -= SCALE; ok = 1; }
    bpf_spin_unlock(&b->lock);
    return ok;
}

SEC("xdp") int xdp_dns_guard(struct xdp_md *ctx) {
    void *data = (void *)(long)ctx->data;
    void *end = (void *)(long)ctx->data_end;
    count(SEEN);
    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > end) return XDP_PASS;
    // Handle up to two VLAN tags (802.1Q / 802.1ad) with fixed bounds.
    __be16 proto = eth->h_proto;
    void *cursor = (void *)(eth + 1);
#pragma unroll
    for (int i = 0; i < 2; i++) {
        if (proto == bpf_htons(ETH_P_8021Q) || proto == bpf_htons(ETH_P_8021AD)) {
            struct vlan_tag *vh = cursor;
            if ((void *)(vh + 1) > end) { count(NON_DNS_PASS); return XDP_PASS; }
            proto = vh->encapsulated_proto;
            cursor = vh + 1;
        }
    }
    // IPv6, triple-tagged and non-IPv4 traffic are explicitly out of scope.
    if (proto != bpf_htons(ETH_P_IP)) { count(NON_DNS_PASS); return XDP_PASS; }
    struct iphdr *ip = cursor;
    if ((void *)(ip + 1) > end || ip->version != 4 || ip->ihl < 5) { count(NON_DNS_PASS); return XDP_PASS; }
    __u32 ihl_bytes = (__u32)ip->ihl * 4;
    if ((void *)ip + ihl_bytes > end) { count(NON_DNS_PASS); return XDP_PASS; }
    __u32 ip_len = bpf_ntohs(ip->tot_len);
    if (ip_len < ihl_bytes || (void *)ip + ip_len > end) {
        count(NON_DNS_PASS); return XDP_PASS;
    }
    if (ip->protocol != IPPROTO_UDP) { count(NON_DNS_PASS); return XDP_PASS; }
    if (bpf_ntohs(ip->frag_off) & 0x3fff) { count(PASS_FRAGMENT); return XDP_PASS; }
    struct udphdr *udp = (void *)ip + ihl_bytes;
    if ((void *)(udp + 1) > end) { count(NON_DNS_PASS); return XDP_PASS; }
    if (udp->dest != bpf_htons(DNS_PORT)) { count(NON_DNS_PASS); return XDP_PASS; }
    __u16 udp_len = bpf_ntohs(udp->len);
    if (udp_len < sizeof(*udp) + sizeof(struct dns_hdr) ||
        udp_len > ip_len - ihl_bytes) { count(DROP_MALFORMED); return XDP_DROP; }
    void *dns_end = (void *)udp + udp_len;
    if (dns_end > end) { count(DROP_MALFORMED); return XDP_DROP; }
    struct dns_hdr *dns = (void *)(udp + 1);
    if ((void *)(dns + 1) > dns_end || bpf_ntohs(dns->qd) != 1 || (bpf_ntohs(dns->flags) & 0x8000)) {
        count(DROP_MALFORMED); return XDP_DROP;
    }
    unsigned char *name = (void *)(dns + 1);
    __u32 off = 0;
    int terminated = 0;
    // Bounded loop: a 255-byte QNAME can contain at most 128 labels.
    // Avoid fully unrolling 255 iterations (large BPF instruction footprint).
    for (int i = 0; i < 128; i++) {
        if (terminated) break;
        if ((void *)(name + off + 1) > dns_end) { count(DROP_MALFORMED); return XDP_DROP; }
        __u8 len = *(name + off);
        if ((len & 0xc0) || len > 63 || off + (__u32)len + 1 > MAX_NAME_WIRE) { count(DROP_MALFORMED); return XDP_DROP; }
        off += (__u32)len + 1;
        if (!len) { terminated = 1; break; }
        if ((void *)(name + off) > dns_end) { count(DROP_MALFORMED); return XDP_DROP; }
    }
    if (!terminated || (void *)(name + off + 4) > dns_end) { count(DROP_MALFORMED); return XDP_DROP; }
    __u32 zero = 0;
    struct settings *cfg = bpf_map_lookup_elem(&config, &zero);
    if (!cfg || !cfg->per_rate || !cfg->global_rate || !cfg->per_burst || !cfg->global_burst ||
        cfg->per_rate > MAX_RATE || cfg->global_rate > MAX_RATE ||
        cfg->per_burst > MAX_BURST || cfg->global_burst > MAX_BURST) {
        count(MAP_FAILURE); return XDP_PASS; // fail open: documented policy
    }
    __u32 src = ip->saddr;
    struct bucket *sb = bpf_map_lookup_elem(&sources, &src);
    if (!sb) {
        struct bucket blank = {};
        bpf_map_update_elem(&sources, &src, &blank, BPF_NOEXIST);
        sb = bpf_map_lookup_elem(&sources, &src);
    }
    struct bucket *gb = bpf_map_lookup_elem(&global_bucket, &zero);
    if (!sb || !gb) { count(MAP_FAILURE); return XDP_PASS; }
    __u64 now = bpf_ktime_get_ns();
    // Reserve global capacity first: global drops do not debit source quota.
    if (!allow(gb, cfg->global_rate, cfg->global_burst, now)) { count(DROP_GLOBAL); return XDP_DROP; }
    if (!allow(sb, cfg->per_rate, cfg->per_burst, now)) {
        // Return the global reservation. An intervening refill can fill the bucket;
        // in that case cap the refund to the configured burst.
        bpf_spin_lock(&gb->lock);
        __u64 cap = (__u64)cfg->global_burst * SCALE;
        gb->tokens = gb->tokens >= cap - SCALE ? cap : gb->tokens + SCALE;
        bpf_spin_unlock(&gb->lock);
        count(DROP_SOURCE); return XDP_DROP;
    }
    count(DNS_PASS);
    return XDP_PASS;
}
char LICENSE[] SEC("license") = "GPL";
