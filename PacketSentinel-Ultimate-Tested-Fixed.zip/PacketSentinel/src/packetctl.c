// SPDX-License-Identifier: MIT
#include <bpf/libbpf.h>
#include <bpf/bpf.h>
#include <linux/if_link.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <stdint.h>

struct settings { uint32_t per_rate, per_burst, global_rate, global_burst; };
enum { SEEN, DNS_PASS, NON_DNS_PASS, DROP_SOURCE, DROP_GLOBAL, DROP_MALFORMED, PASS_FRAGMENT, MAP_FAILURE, NUM_STATS };
static const char *names[] = {"seen","dns_pass","non_dns_pass","drop_source","drop_global","drop_malformed","pass_fragment","map_failure"};
static void usage(const char *p) {
 fprintf(stderr,"Usage: %s attach IFACE [native|generic] [per_rate per_burst global_rate global_burst]\n       %s stats IFACE\n       %s detach IFACE [native|generic]\n",p,p,p);
}
static int idx(const char *ifname) { int n = if_nametoindex(ifname); if (!n) fprintf(stderr,"Invalid interface: %s\n",ifname); return n; }
static int flags(const char *arg) { return XDP_FLAGS_UPDATE_IF_NOEXIST | ((arg && !strcmp(arg,"generic")) ? XDP_FLAGS_SKB_MODE : XDP_FLAGS_DRV_MODE); }
static int map_fd(int ifindex, const char *name) {
 char path[256]; snprintf(path,sizeof(path),"/sys/fs/bpf/packetsentinel_%d/%s",ifindex,name);
 return bpf_obj_get(path);
}
int main(int argc, char **argv) {
 if (argc<3) {usage(argv[0]);return 2;}
 int ifindex=idx(argv[2]); if (!ifindex) return 2;
 char dir[256]; snprintf(dir,sizeof(dir),"/sys/fs/bpf/packetsentinel_%d",ifindex);
 if (!strcmp(argv[1],"attach")) {
  if (argc != 4 && argc != 8) {usage(argv[0]);return 2;}
  if (strcmp(argv[3], "native") && strcmp(argv[3], "generic")) {usage(argv[0]);return 2;}
  struct settings s = {200,400,800,1600};
  if (argc==8) {
   unsigned *arr[] = {&s.per_rate,&s.per_burst,&s.global_rate,&s.global_burst};
   for (int j=0;j<4;j++) {char *e; unsigned long v=strtoul(argv[j+4],&e,10);if (e==argv[j+4] || *e || v<1 || v>100000) {fprintf(stderr,"Rate/burst must be 1..100000\n"); return 2;} *arr[j]=(unsigned)v;}
  }
  struct bpf_object *obj=bpf_object__open_file("build/xdp_dns.o",NULL);
  if (!obj || libbpf_get_error(obj)) {fprintf(stderr,"Cannot open build/xdp_dns.o; run make\n");return 1;}
  int err=bpf_object__load(obj);
  if (err) {fprintf(stderr,"BPF load failed: %d (check root/kernel/features)\n",err);bpf_object__close(obj);return 1;}
  struct bpf_program *prog=bpf_object__find_program_by_name(obj,"xdp_dns_guard");
  struct bpf_map *cfg=bpf_object__find_map_by_name(obj,"config");
  if (!prog || !cfg) {fprintf(stderr,"Missing BPF symbols\n");bpf_object__close(obj);return 1;}
  uint32_t zero=0;
  if (bpf_map_update_elem(bpf_map__fd(cfg),&zero,&s,BPF_ANY)) {perror("config update");bpf_object__close(obj);return 1;}
  int mode=flags(argv[3]);
  err=bpf_xdp_attach(ifindex,bpf_program__fd(prog),mode,NULL);
  if (err) {fprintf(stderr,"XDP attach failed: %d; try generic mode\n",err);bpf_object__close(obj);return 1;}
  if (mkdir(dir,0700) && errno!=EEXIST) {perror("mkdir bpffs");bpf_xdp_detach(ifindex,mode & ~XDP_FLAGS_UPDATE_IF_NOEXIST,NULL);bpf_object__close(obj);return 1;}
  const char *maps[]={"sources","global_bucket","config","stats"};
  for (int j=0;j<4;j++) {
   struct bpf_map *m=bpf_object__find_map_by_name(obj,maps[j]); char path[320];snprintf(path,sizeof(path),"%s/%s",dir,maps[j]);
   err=m ? bpf_map__pin(m,path) : -ENOENT;
   if (err) {
    fprintf(stderr,"Map pin failed: %s (%d); rolling back attachment and pins\n",path,err);
    bpf_xdp_detach(ifindex,mode & ~XDP_FLAGS_UPDATE_IF_NOEXIST,NULL);
    for (int k=0;k<j;k++) {char old[320];snprintf(old,sizeof(old),"%s/%s",dir,maps[k]);unlink(old);}
    rmdir(dir);bpf_object__close(obj);return 1;
   }
  }
  printf("Attached on %s (%s). Rates: per=%u/%u global=%u/%u packets/s, burst.\n",argv[2],argv[3],s.per_rate,s.per_burst,s.global_rate,s.global_burst);
  bpf_object__close(obj); return 0;
 }
 if (!strcmp(argv[1],"stats")) {
  if (argc != 3) {usage(argv[0]);return 2;}
  int fd=map_fd(ifindex,"stats");if(fd<0) {perror("open stats map");return 1;}
  int n=libbpf_num_possible_cpus(); if(n<1) {close(fd);return 1;}
  uint64_t *values=calloc((size_t)n,sizeof(*values)); if(!values) {close(fd);return 1;}
  putchar('{');for(uint32_t k=0;k<NUM_STATS;k++) {uint64_t sum=0;if(bpf_map_lookup_elem(fd,&k,values)) {perror("read counter");free(values);close(fd);return 1;}
    for(int c=0;c<n;c++) sum+=values[c]; printf("%s\"%s\":%llu",k?",":"",names[k],(unsigned long long)sum);}
  puts("}");free(values);close(fd);return 0;
 }
 if (!strcmp(argv[1],"detach")) {
  if (argc > 4 || (argc == 4 && strcmp(argv[3],"native") && strcmp(argv[3],"generic"))) {usage(argv[0]);return 2;}
  int mode=flags(argc>3?argv[3]:"native") & ~XDP_FLAGS_UPDATE_IF_NOEXIST;
  int rc=bpf_xdp_detach(ifindex,mode,NULL);
  if (rc) {fprintf(stderr,"detach failed %d (check mode); pins preserved\n",rc);return 1;}
  const char *maps[]={"sources","global_bucket","config","stats"};
  for(int j=0;j<4;j++){char p[320];snprintf(p,sizeof(p),"%s/%s",dir,maps[j]);unlink(p);} rmdir(dir);
  printf("Detached %s\n",argv[2]);return 0;
 }
 usage(argv[0]);return 2;
}
