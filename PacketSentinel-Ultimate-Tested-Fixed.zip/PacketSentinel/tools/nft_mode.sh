#!/usr/bin/env bash
set -euo pipefail
case "${1:-}" in
  on) sudo nft -c -f config/nftables.nft; sudo nft -f config/nftables.nft ;;
  off) sudo nft delete table ip packetsentinel ;;
  show) sudo nft -a list table ip packetsentinel ;;
  *) echo 'Usage: tools/nft_mode.sh on|off|show' >&2; exit 2;;
esac
