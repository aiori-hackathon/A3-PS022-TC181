#!/usr/bin/env python3
"""Combine manually synchronized per-run JSON files into a CSV row."""
import argparse
import csv
import json
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['none','nftables','xdp'],required=True);p.add_argument('--pattern',choices=['steady','bursty','ramp'],required=True);p.add_argument('--load',required=True);p.add_argument('--probe',required=True);p.add_argument('--metrics',required=True);p.add_argument('--xdp-before');p.add_argument('--xdp-after');p.add_argument('--output',default='results/runs.csv');a=p.parse_args()
 data={'mode':a.mode,'pattern':a.pattern}
 for name,path in [('load',a.load),('probe',a.probe),('metrics',a.metrics)]:
  vals=json.loads(Path(path).read_text())
  if name=='load': data['achieved_pps']=vals['achieved_pps'];data['sent']=vals['sent']
  if name=='probe': data['success_pct']=vals['success_pct'];data['success']=vals['success'];data['queries']=vals['sent'];data['avg_latency_ms']=vals['avg_latency_ms']
  if name=='metrics':data['cpu_busy_pct']=vals['cpu_busy_pct'];data['rx_dropped_delta']=vals['rx_dropped_delta']
 if bool(a.xdp_before) != bool(a.xdp_after): p.error('Both XDP snapshots are required')
 if a.mode == 'xdp' and not a.xdp_before: p.error('XDP mode requires both --xdp-before and --xdp-after snapshots')
 if a.mode != 'xdp' and (a.xdp_before or a.xdp_after): p.error('XDP snapshots only valid for xdp mode')
 if a.xdp_before and a.xdp_after:
  before=json.loads(Path(a.xdp_before).read_text());after=json.loads(Path(a.xdp_after).read_text())
  deltas=[after[k]-before[k] for k in ('drop_source','drop_global','drop_malformed')]
  if any(n < 0 for n in deltas): p.error('XDP counters went backwards: reset/re-attach during test?')
  data['xdp_drop_delta']=sum(deltas)
 else:data['xdp_drop_delta']=''
 path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True)
 fields=['mode','pattern','achieved_pps','sent','success_pct','success','queries','avg_latency_ms','cpu_busy_pct','rx_dropped_delta','xdp_drop_delta']
 exists=path.exists()
 with path.open('a',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields)
  if not exists:writer.writeheader()
  writer.writerow(data)
 print(json.dumps(data,indent=2))
if __name__=='__main__':main()
