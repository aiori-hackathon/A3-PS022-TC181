#!/usr/bin/env python3
"""Read-only receiver checks for active XDP/nftables configurations.

Run on Host B via sudo -n python3 tools/verify_mode.py --iface IFACE --mode MODE.
This intentionally fails if any other XDP program is attached: never overwrite it.
"""
import argparse
import json
import re
import subprocess


def check_mode(mode, xdp, nft):
    xdp_active = bool(xdp)
    nft_active = nft
    if mode == 'none':
        return not xdp_active and not nft_active
    if mode == 'nftables':
        return nft_active and not xdp_active
    return xdp_active and not nft_active


def main():
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--iface', required=True)
    a.add_argument('--mode', choices=('none', 'nftables', 'xdp'), required=True)
    args = a.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,15}', args.iface):
        a.error('invalid interface')
    link = subprocess.run(['ip', '-j', '-d', 'link', 'show', 'dev', args.iface], capture_output=True, text=True)
    if link.returncode:
        raise SystemExit('Cannot inspect interface: ' + link.stderr.strip())
    info = json.loads(link.stdout)[0]
    # iproute2 commonly exposes xdp as xdp: {attached:..., prog:...}.
    xdp = info.get('xdp') or {}
    attached = str(xdp.get('attached', 'off')).lower() not in ('off', 'none', '0', 'false')
    if not attached and xdp.get('prog'):
        attached = True
    nft = subprocess.run(['nft', '-j', 'list', 'table', 'ip', 'packetsentinel'], capture_output=True, text=True)
    if nft.returncode and ('permission denied' in nft.stderr.lower() or 'operation not permitted' in nft.stderr.lower()):
        raise SystemExit('Cannot inspect nftables: run as root')
    nft_active = nft.returncode == 0
    ok = check_mode(args.mode, attached, nft_active)
    print(json.dumps(dict(mode=args.mode, iface=args.iface, xdp_attached=attached, nft_table=nft_active, verified=ok)))
    if not ok:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
