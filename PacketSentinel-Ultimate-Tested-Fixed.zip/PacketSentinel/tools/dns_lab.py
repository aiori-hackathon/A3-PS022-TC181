#!/usr/bin/env python3
"""Standard-library-only, intentionally capped private-network DNS lab client/server."""
import argparse
import ipaddress
import json
import random
import socket
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor

MAX_PPS = 2000
MAX_SECONDS = 30
MAX_WORKERS = 8


def private_target(host):
    ip = ipaddress.ip_address(host)
    # Explicitly prohibit publicly routable, multicast, unspecified, loopback or link-local targets.
    if not (ip.is_private and not (ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified)):
        raise ValueError("Target must be an RFC1918 private IPv4 lab address (not localhost)")
    if ip.version != 4 or not any(ip in ipaddress.ip_network(n) for n in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')):
        raise ValueError("Target must be an RFC1918 private IPv4 lab address")
    return host


def encode_query(qid, name='lab.test'):
    if not 0 <= qid <= 65535:
        raise ValueError('DNS query ID must fit 16 bits')
    try:
        labels = [x.encode('ascii') for x in name.split('.')]
    except UnicodeEncodeError as exc:
        raise ValueError('Only ASCII DNS labels are supported') from exc
    if not labels or any(not x or len(x) > 63 or any(not (c in b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-') for c in x) or x.startswith(b'-') or x.endswith(b'-') for x in labels) or sum(map(len, labels)) + len(labels) + 1 > 255:
        raise ValueError('Invalid DNS name')
    qname = b''.join(bytes([len(x)]) + x for x in labels) + b'\x00'
    return struct.pack('!HHHHHH', qid, 0x0100, 1, 0, 0, 0) + qname + struct.pack('!HH', 1, 1)


def server(bind, port, stop_event=None):
    """Minimal fixed-answer UDP DNS responder; not a recursive resolver."""
    if bind == '0.0.0.0':
        raise ValueError('Bind to a specific lab IPv4 address, not all interfaces')
    if not (bind == '127.0.0.1' and port != 53):
        private_target(bind)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((bind, port))
    s.settimeout(.25)
    print(f'DNS lab responder listening at {bind}:{port}', flush=True)
    try:
        while stop_event is None or not stop_event.is_set():
            try:
                data, addr = s.recvfrom(512)
            except socket.timeout:
                continue
            if len(data) < 17 or data[2] & 0x80 or data[4:6] != b'\x00\x01':
                continue
            # Return a valid no-answer authoritative response, preserving question.
            response = data[:2] + struct.pack('!HHHHH', 0x8500, 1, 0, 0, 0) + data[12:]
            s.sendto(response, addr)
    finally:
        s.close()


def probe(target, port, count, interval, timeout):
    successes, timings = 0, []
    expected_peer = (target, port)
    for i in range(count):
        qid = random.randrange(65536)
        payload = encode_query(qid)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout)
            start = time.monotonic()
            sock.sendto(payload, (target, port))
            try:
                resp, peer = sock.recvfrom(1024)
                if (peer == expected_peer and len(resp) >= 12 and resp[:2] == payload[:2]
                    and (resp[2] & 0x80) and resp[3] & 0x0f == 0
                    and resp[4:6] == b'\x00\x01' and resp[12:] == payload[12:]):
                    successes += 1
                    timings.append((time.monotonic() - start) * 1000)
            except socket.timeout:
                pass
        if i + 1 < count:
            time.sleep(interval)
    return dict(sent=count, success=successes, success_pct=round(100 * successes / max(count, 1), 2), avg_latency_ms=round(sum(timings) / len(timings), 3) if timings else None)


def load_worker(target, port, duration, rate, pattern, seed, stats):
    rnd = random.Random(seed)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sent = 0
    start = time.monotonic()
    next_at = start
    try:
        while time.monotonic() - start < duration:
            elapsed = time.monotonic() - start
            if pattern == 'bursty':
                # 0.5-second on/off with the same nominal offered average rate.
                if int(elapsed * 2) % 2:
                    time.sleep(.01)
                    next_at = time.monotonic()
                    continue
                active_rate = rate * 2
            elif pattern == 'ramp':
                active_rate = max(1, rate * (.25 + .75 * elapsed / duration))
            else:
                active_rate = rate
            next_at += 1 / active_rate
            if next_at > time.monotonic():
                time.sleep(next_at - time.monotonic())
            else:
                next_at = time.monotonic()
            sock.sendto(encode_query(rnd.randrange(65536), 'q%04d.lab.test' % rnd.randrange(10000)), (target, port))
            sent += 1
    finally:
        sock.close()
    stats.append(sent)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='cmd', required=True)
    srv = sub.add_parser('server'); srv.add_argument('--bind', required=True);srv.add_argument('--port',type=int,default=53)
    check = sub.add_parser('probe'); check.add_argument('--target',required=True);check.add_argument('--port',type=int,default=53);check.add_argument('--count',type=int,default=30);check.add_argument('--interval',type=float,default=.1);check.add_argument('--timeout',type=float,default=.3)
    flood = sub.add_parser('load');flood.add_argument('--target',required=True);flood.add_argument('--port',type=int,default=53);flood.add_argument('--pattern',choices=['steady','bursty','ramp'],required=True);flood.add_argument('--pps',type=int,default=300);flood.add_argument('--seconds',type=int,default=10);flood.add_argument('--workers',type=int,default=2)
    a = p.parse_args()
    if a.cmd == 'server':
        if a.port != 53: p.error('Use port 53 for equivalent XDP tests')
        server(a.bind,a.port)
    else:
        try: private_target(a.target)
        except ValueError as e: p.error(str(e))
        if a.port != 53: p.error('Use port 53: XDP parser filters only UDP/53')
        if a.cmd == 'probe':
            if not 1 <= a.count <= 500 or not .01 <= a.interval <= 10 or not .05 <= a.timeout <= 3: p.error('Probe arguments out of bounds')
            print(json.dumps(probe(a.target,a.port,a.count,a.interval,a.timeout)))
        else:
            if not 1 <= a.pps <= MAX_PPS or not 1 <= a.seconds <= MAX_SECONDS or not 1 <= a.workers <= MAX_WORKERS: p.error('Lab safety caps exceeded')
            shares = [a.pps // a.workers + (1 if k < a.pps % a.workers else 0) for k in range(a.workers)]
            totals=[]
            with ThreadPoolExecutor(max_workers=a.workers) as ex:
                tasks = [ex.submit(load_worker,a.target,a.port,a.seconds,r,a.pattern,i,totals) for i,r in enumerate(shares) if r]
                for t in tasks: t.result()
            print(json.dumps(dict(pattern=a.pattern,configured_pps=a.pps,seconds=a.seconds,sent=sum(totals),achieved_pps=round(sum(totals)/a.seconds,2))))

if __name__ == '__main__': main()
