#!/usr/bin/env python3
"""Make performance comparisons from real CSV data (never synthetic scores)."""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
import statistics


def aggregate(rows, field):
    data = defaultdict(list)
    for r in rows:
        try:
            value = float(r[field])
            data[(r['pattern'], r['mode'])].append(value)
        except (ValueError, KeyError, TypeError):
            pass
    return {key: statistics.mean(v) for key, v in data.items() if v}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('csv')
    p.add_argument('--out', default='results/charts')
    a = p.parse_args()
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError as e:
        p.error('Install matplotlib to generate charts: python3 -m pip install matplotlib')
    with open(a.csv, newline='') as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        p.error('No measured rows available')
    Path(a.out).mkdir(parents=True, exist_ok=True)
    patterns = ['steady', 'bursty', 'ramp']
    modes = ['none', 'nftables', 'xdp']
    for metric, label in [('cpu_busy_pct', 'Receiver CPU busy (%)'), ('success_pct', 'Legitimate query success (%)'), ('achieved_pps', 'Achieved sent queries/s')]:
        means = aggregate(rows, metric)
        if not means:
            continue
        fig, ax = plt.subplots(figsize=(9, 4.5))
        for j, mode in enumerate(modes):
            xs = [i + (j-1)*.25 for i in range(len(patterns))]
            ys = [means.get((pat, mode), float('nan')) for pat in patterns]
            ax.bar(xs, ys, width=.24, label=mode)
        ax.set_xticks(range(len(patterns)), patterns)
        ax.set_ylabel(label)
        ax.set_title(label + ' — measured values only')
        ax.legend()
        fig.tight_layout()
        fig.savefig(Path(a.out)/f'{metric}.png', dpi=160)
        plt.close(fig)


if __name__ == '__main__':
    main()
