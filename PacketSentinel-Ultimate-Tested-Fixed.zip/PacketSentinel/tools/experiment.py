#!/usr/bin/env python3
"""Operator-controlled experiment on Host A, SSH metrics on authorized Host B.

Does not modify firewall/XDP configuration. Operators select a mode on Host B
before running this script; all load is capped by dns_lab.py.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import dns_lab


def run_capture(command, path):
    proc = subprocess.run(command, text=True, capture_output=True, check=True)
    data = json.loads(proc.stdout.strip())
    path.write_text(json.dumps(data, indent=2) + '\n')
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True, help='Private Host B IPv4 address')
    parser.add_argument('--receiver', required=True, help='SSH user@Host-B (key-based SSH)')
    parser.add_argument('--iface', required=True, help='Host B receiving interface')
    parser.add_argument('--mode', choices=['none', 'nftables', 'xdp'], required=True)
    parser.add_argument('--pps', type=int, default=300)
    parser.add_argument('--seconds', type=int, default=10)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--out', default='results')
    a = parser.parse_args()
    try:
        dns_lab.private_target(a.target)
    except ValueError as exc:
        parser.error(str(exc))
    if not 1 <= a.pps <= dns_lab.MAX_PPS or not 2 <= a.seconds <= dns_lab.MAX_SECONDS or not 1 <= a.repeats <= 10:
        parser.error('Experiment safety bounds exceeded')
    if not a.iface.replace('-', '').replace('_','').replace('.','').isalnum() or len(a.iface) > 15:
        parser.error('Invalid interface name')
    if a.receiver.startswith('-') or not all(ch.isalnum() or ch in '.-_@' for ch in a.receiver):
        parser.error('Invalid receiver')
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    py = sys.executable
    for pattern in ('steady', 'bursty', 'ramp'):
        for repeat in range(1, a.repeats + 1):
            prefix = out / f'{a.mode}_{pattern}_{repeat}'
            def ssh_cmd(*args):
                return ['ssh', '-o', 'BatchMode=yes', a.receiver, *args]
            run_capture(ssh_cmd('sudo', '-n', 'python3', 'tools/verify_mode.py', '--iface', a.iface, '--mode', a.mode), Path(str(prefix)+'_mode.json'))
            if a.mode == 'xdp':
                run_capture(ssh_cmd('sudo', '-n', './build/packetctl', 'stats', a.iface), Path(str(prefix)+'_before.json'))
            # Start receiver CPU measurement and legitimate probes concurrently with load.
            with ThreadPoolExecutor(max_workers=3) as ex:
                measurement = ex.submit(run_capture, ssh_cmd('python3', 'tools/metrics.py', '--iface', a.iface, '--seconds', str(a.seconds)), Path(str(prefix)+'_metrics.json'))
                probes = ex.submit(run_capture, [py, 'tools/dns_lab.py', 'probe', '--target', a.target, '--count', '30', '--interval', str(max(.01, (a.seconds - 1)/30)), '--timeout', '.25'], Path(str(prefix)+'_probe.json'))
                load = ex.submit(run_capture, [py, 'tools/dns_lab.py', 'load', '--target', a.target, '--pattern', pattern, '--pps', str(a.pps), '--seconds', str(a.seconds), '--workers', '2'], Path(str(prefix)+'_load.json'))
                for job in (measurement, probes, load):
                    job.result()
            if a.mode == 'xdp':
                run_capture(ssh_cmd('sudo', '-n', './build/packetctl', 'stats', a.iface), Path(str(prefix)+'_after.json'))
            combine = [py, 'tools/compare.py', '--mode', a.mode, '--pattern', pattern,
                       '--load', str(prefix)+'_load.json', '--probe', str(prefix)+'_probe.json',
                       '--metrics', str(prefix)+'_metrics.json', '--output', str(out/'runs.csv')]
            if a.mode == 'xdp':
                combine += ['--xdp-before', str(prefix)+'_before.json', '--xdp-after', str(prefix)+'_after.json']
            subprocess.run(combine, check=True)
            print(f'Finished {a.mode}/{pattern}/{repeat}', flush=True)
            time.sleep(2)
    print('Mode complete. Change Host B mode manually and run again.')


if __name__ == '__main__':
    main()
