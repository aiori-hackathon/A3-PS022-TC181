#!/usr/bin/env python3
"""Collect CPU and interface RX drops on Host B during a scheduled test window."""
import argparse
import json
from pathlib import Path
import time


def read_cpu():
    line = Path('/proc/stat').read_text().splitlines()[0].split()[1:]
    v = list(map(int,line))
    return sum(v), v[3] + v[4]  # total ticks, idle+IO-wait


def rx_drops(iface):
    return int(Path(f'/sys/class/net/{iface}/statistics/rx_dropped').read_text())


def collect(iface,seconds):
    a,b=read_cpu();d=rx_drops(iface)
    time.sleep(seconds)
    c,e=read_cpu();f=rx_drops(iface)
    return dict(cpu_busy_pct=round(100*(1-(e-b)/max(1,c-a)),2),rx_dropped_delta=f-d,window_seconds=seconds,interface=iface)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--iface',required=True);p.add_argument('--seconds',type=int,default=10); a=p.parse_args()
    if not 1<=a.seconds<=60 or not Path(f'/sys/class/net/{a.iface}').exists():p.error('Invalid interface or duration')
    print(json.dumps(collect(a.iface,a.seconds)))
