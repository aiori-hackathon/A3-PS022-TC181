#!/usr/bin/env python3
"""Summarize observed result rows; never invent missing measurements."""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


def summarize(rows):
    out=defaultdict(list)
    for row in rows:
        key=(row.get('mode',''),row.get('pattern',''))
        for field in ('cpu_busy_pct','success_pct','achieved_pps','rx_dropped_delta','xdp_drop_delta'):
            value = row.get(field)
            if value in (None, ''):
                continue
            try:
                number = float(value)
            except (TypeError, ValueError):
                continue
            if number != number or number in (float('inf'), float('-inf')):
                continue
            out[(key,field)].append(number)
    return [{'mode':key[0][0],'pattern':key[0][1],'metric':key[1], 'mean':round(sum(values)/len(values),3),'samples':len(values)} for key,values in sorted(out.items())]


def main():
    p=argparse.ArgumentParser();p.add_argument('input',help='CSV from manually consolidated runs');p.add_argument('--output',default='results/summary.json');a=p.parse_args()
    with open(a.input,newline='') as f: rows=list(csv.DictReader(f))
    report=summarize(rows); Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    Path(a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':main()
