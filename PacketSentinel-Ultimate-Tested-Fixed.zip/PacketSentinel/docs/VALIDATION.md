# Validation status and remaining work

## Verified in packaging environment

- Python standard-library unit tests can run without root or network infrastructure.
- Python source compilation verifies syntax, not packet behavior.
- The `experiment.py` runner and `plot_results.py` provide an instrumented comparison workflow but require real inputs.

## Not verified here

- Compilation with a Linux-capable Clang BPF backend and libbpf headers.
- Kernel eBPF verifier acceptance or NIC/XDP compatibility.
- A real two-host test, packet-drop behavior, CPU advantage, and end-to-end DNS success.
- Nftables per-source meter semantics on target kernel; validate command and counters.

## Technical boundaries

- Parses Ethernet with 0–2 VLAN tags, IPv4 UDP port 53, DNS header and first question; IPv6, more than two VLAN tags, fragmented traffic, IPv4 options semantics and TCP DNS are not comprehensively filtered.
- Maximum DNS QNAME wire bytes is 255; DNS compression pointers in the first question are deliberately rejected. This is a bounded experiment, not a production DNS parser.
- Global capacity is reserved before per-source capacity. If the source limit rejects a packet, the implementation attempts a capped global-token refund; concurrent updates may make the refund conservative.
- Existing source IPs can be evicted when the LRU hash is full. Eviction and source spoofing make this non-definitive as an anti-DDoS firewall.
- Filter fails open if configuration/map lookup is unavailable. IPv6 and nonmatching protocols pass by design.
- Generic XDP operates later in the receive stack than native mode; do not claim equivalent CPU effects.
- `rx_dropped` does not necessarily include XDP drops. Counters must be interpreted separately.
- `experiment.py` requires passwordless SSH and permitted noninteractive sudo on Host B for XDP stats, and invocation from repository directory on both hosts.
- DNS probe compares returned query/question and ID but is not a full RFC 1035 resolver verifier.

## Recommended final evidence

Capture exact OS/kernel/NIC info, CI log, successful native or generic attach, receiver and sender command logs, 27 complete matched measurements (three modes x three patterns x three repeats), CSV, plots, and mentor demo. Use `reports/PacketSentinel-Technical-Report.pdf` as a draft until you insert measured results and verify the organizers' exact PDF template.
