# Architecture and technical decisions

```mermaid
flowchart LR
 A[Host A: private synthetic DNS load + probes] --> B[Host B NIC ingress]
 B --> C{XDP bounded parser}
 C -->|non-target or excluded| K[Linux network stack]
 C -->|malformed DNS| D[Drop + counter]
 C --> S{Per-source token bucket}
 S -->|limit exceeded| D
 S --> G{Global token bucket}
 G -->|limit exceeded| D
 G -->|admit| K
 K --> L[Lab UDP/53 responder]
 C --> M[(eBPF maps)]
 S --> M
 G --> M
 M --> O[packetctl stats / recorded JSON]
```

## Algorithm

Packet checks have finite bounds at each step. A valid DNS query reaches two token buckets. For a bucket with limit R packets/s and burst B, tokens T are represented as a 64-bit fixed point number of nanosecond units (1 packet = 10^9). Refill is saturation-safe: if elapsed time is enough to fill the bucket, set `T=B*10^9`; otherwise add `delta_ns*R`, bounded by capacity. A packet is allowed if `T>=10^9`, then the token is deducted. Per-bucket spinlocks serialize simultaneous updates. Counters are per CPU to reduce write contention.

The implementation caps DNS first-name wire format at 255 bytes and limits individual labels to 63 bytes. It intentionally rejects first-question compression and does not interpret all DNS classes/types, EDNS0 or options. Truncated/invalid fixed headers reaching port 53 are dropped; malformed non-UDP/IPv4 are passed as non-target. This implementation is **not** a full DNS parser or reflection mitigation engine.

## Threat model

Authorized local sender can generate UDP queries against only an isolated receiver and may exceed receiver capacity. Success criteria are reduction of measured packet-processing overhead while preserving a useful fraction of legitimate queries; no guarantees without measurement. Source spoofing, IPv6, IPv4 fragments, malicious application payloads, amplification and distributed Internet traffic are not covered. The parser handles up to two VLAN tags, but VLAN-specific behavior still requires integration testing.

## Limitations and future work

1. Add IPv6 support only if the scope requires it; current parser handles up to two VLAN tags, which still needs lab verification.
2. Validate IP total length/UDP checksum and pathological framing more fully.
3. Add per-CPU/global sharding to reduce global lock contention; then quantify fairness error.
4. Integrate monotonic, fully synchronized experiment orchestration and structured nftables counter parsing.
5. Add live observability (Prometheus/OpenTelemetry) after the initial measurements.
6. Test under exact kernels and NICs to document native versus generic performance and source IP churn.

## Fair comparisons

No-filter is a performance control, not a rate-limit equivalence. nftables' native meter algorithms may differ from XDP's fixed point token buckets. Both can enforce the same nominal pps/burst configuration but **not** equivalent packet admission at every millisecond. Report observed values and explain disparities rather than claiming mathematical identity.
