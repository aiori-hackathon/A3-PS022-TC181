# Experiment protocol and acceptance criteria

## Matrix

| Mode | steady | bursty | ramp |
|---|---|---|---|
| No filter | 3 repeats | 3 repeats | 3 repeats |
| nftables | 3 repeats | 3 repeats | 3 repeats |
| Native XDP or generic fallback | 3 repeats | 3 repeats | 3 repeats |

Total minimum: **27 runs**. Keep measured rate, successful probes, receiver CPU, interface counters, and limiter counters. Repeat the same random seed schedule across modes where possible; network scheduling and kernel state will still vary.

## Preflight checklist

- [ ] Written authorization for both hosts and dedicated lab network.
- [ ] Record hardware model, NIC/driver, kernel version, CPU count, distro, clocks and XDP native/generic mode.
- [ ] Verify actual private addresses, routing and interface receiving inbound packets.
- [ ] Check that no other firewall/XDP mechanism is affecting DNS; do not globally flush rules.
- [ ] Verify server returns a successful DNS response with **no load**.
- [ ] Verify all filters removed at the start of no-filter baseline.
- [ ] Ensure proposed traffic stays within the 2,000 PPS and 30 s safety limits.
- [ ] Randomize mode order across repeats if possible; leave cooldown between tests.
- [ ] Store raw command outputs, kernel verifier error logs and nftables counter snapshots.

## Definition of done

- Program builds, loads and attaches to RX interface without kernel verifier errors on target lab.
- Bounded parser handles allowed DNS requests, malformed requests, and non-target traffic as documented.
- Both per-source and global drops are demonstrably nonzero when their respective thresholds are reached.
- Legitimate query success is measured for every mode and scenario, not merely claimed.
- Measured CPU utilization, achieved offered PPS, and drop counters are captured for all 27 runs.
- At least one graph/table includes every baseline and all 3 patterns with uncertainties or min/max.
- The mentor sees the pseudocode and reproducible demonstration.

## Interpreting measurements

**CPU busy %** from `/proc/stat` is entire-host non-idle percentage during the window and includes the sender-independent receiver workload; it is *not per-process CPU*.

**Application success %** = valid DNS responses received / probes sent × 100. It includes transient network/application losses, timeout configuration and queueing. **Latency** is mean of successful probes only; report selection bias.

**Offered load** is packets sent by the Python client divided by the configured duration; it is not wire throughput. Python timing and host scheduling cap achieved rate. **rx_dropped** is the NIC netdev counter and may not expose XDP drops. **xdp_drop_delta** is the sum of XDP map counters for three drop reasons during the window. nftables drop packets should be read from nft counter snapshots separately.

For statistical interpretation, compute mean over repeated runs, show variance or min-max, and avoid claiming causality beyond this lab.

## Automated coordination

`tools/experiment.py` runs nine measurements per selected mode. Select the mode on Host B manually. It sends a bounded load and probes from Host A while requesting receiver CPU counters over authenticated SSH. Follow the README. The data are not a synchronized packet capture or an accurate NIC wire-rate measurement.
