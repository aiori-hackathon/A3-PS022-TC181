# Changes in the tested package

Date: 2026-10-29

## Changes included

- `tools/compare.py` requires both XDP counter snapshots for XDP mode and rejects XDP snapshots in `none` and `nftables` modes.
- Added regression tests for the XDP snapshot requirements and counter delta calculation.
- Removed generated `.pytest_cache` files from the distributable ZIP.
- Corrected documentation that no longer matched `src/xdp_dns.c`: parser supports up to two VLAN tags, QNAME wire cap is 255 bytes, global token reservation occurs before per-source checking, and token refill uses saturation-safe elapsed-time handling.
- Kept explicit warnings that the BPF build, kernel verifier, NIC attachment, nftables execution, and real two-host performance tests have not been verified in the packaging environment.

## Verification boundary

Python unit tests and static checks can be run in the current environment. The C/eBPF binary and kernel networking behavior still require a Linux host with the documented development packages, kernel features, privileges, and an isolated lab network. No performance or kernel-level success is claimed by this package.
