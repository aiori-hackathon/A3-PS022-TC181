# Mentor demonstration script (8–12 minutes)

**0–1 min — Problem.** Show host-pair diagram. Explain that XDP can drop unwanted traffic earlier than ordinary netfilter, while generic XDP provides a fallback with different CPU characteristics.

**1–3 min — Code walkthrough.** Open `src/xdp_dns.c`. Show each packet bounds check, fixed 255-byte first-question cap, per-source LRU map, global array map, spinlock and per-CPU counters. Explain the intentionally limited supported protocols and fail-open map errors.

**3–5 min — Live prototype.** Run `make`; then start the Host B responder and Host A low-rate probes. Demonstrate `packetctl attach`, `stats`, `detach` on the real inbound interface. If the native mode fails, show actual error and use `generic`; identify the results honestly.

**5–8 min — Fair baselines.** Demonstrate the three choices, show nftables input table, and run the steady/bursty/ramp generated load only on RFC1918 test address. Capture Host B CPU, XDP counters, successful query percentages and offered PPS. Do not claim results unless the lab has actually yielded them.

**8–10 min — Analysis.** Show `results/runs.csv` and `results/summary.json` based on collected runs; discuss effects on legitimate queries, CPU and packet loss. Acknowledge that receiver netdev drops, nftables counters and XDP counters are distinct measures.

## Pseudocode required by the problem statement

```text
on_rx_packet(packet):
    count(seen)
    if not supported_ipv4_udp(packet):
        return PASS
    if ipv4_is_fragment(packet):
        count(fragment_bypass); return PASS
    if udp_destination != 53:
        return PASS
    if not bounded_dns_header_and_first_question(packet, 255_bytes):
        count(malformed); return DROP
    source_bucket = get_or_initialize_lru_bucket(source_ip)
    global_bucket = get_global_bucket()
    if config_or_map_unavailable:
        count(map_failure); return PASS
    if not global_bucket.take_one_token(now):
        count(global_drops); return DROP
    if not source_bucket.take_one_token(now):
        refund_global_token_within_burst_cap()
        count(source_drops); return DROP
    count(dns_pass); return PASS
```

### Frequently asked mentor questions

**Why not nftables alone?** Native XDP has an earlier drop point, but measurements in this lab determine whether it helps on the target hardware.  
**How is fairness maintained?** Identical conditions, rate settings and repeated runs; document unavoidable algorithmic differences.  
**Why use locks?** They maintain token counter correctness across CPU cores but create a hot shared global bucket.  
**What is excluded?** Public traffic, full DNS parsing, IPv6, IPv4 fragments, source-spoofing defenses, PRSD detection and reflection attack elimination. Up to two VLAN tags are parsed, but that behavior still needs lab validation.  
**What is measurable?** All counters, commands and raw run JSON; performance claims need real runs.
