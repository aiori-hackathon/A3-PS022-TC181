# GitHub upload and submission

1. Create a **private** repository named with the registered team name (the packet proposal uses "PacketSentinel").
2. Locally, from this folder:
   ```bash
   git init
   git branch -M main
   git add .
   git commit -m "feat: bounded XDP DNS rate limiter and controlled benchmark lab"
   git remote add origin git@github.com:YOUR_USERNAME/YOUR_TEAM_NAME.git
   git push -u origin main
   ```
3. On GitHub, open **Settings → Collaborators/Access** and invite `aiori-hackathon` (as specified by PS-022). The brief additionally requests **transferring repository ownership** to that account after its acceptance. Confirm timing/terms with the organizer and ensure the team retains appropriate access before transfer.
4. Upload the PDF report in `reports/` and adapt it to the **official** `Proposed-structure-hackathon.pdf` template if that document differs from the supplied proposal.
5. Add actual tested benchmark CSV/JSON and proof/screenshots from Host A/Host B. Remove sensitive data before upload and temporarily adjust `.gitignore` if publishing selected evidence.
6. Confirm build status in GitHub Actions, walkthrough instructions, mentor demo, report, collaborator and owner requirements.

**Important:** This archive was prepared offline and **has not been pushed to GitHub**. Creating the repository, inviting collaborators, ownership transfer and obtaining real lab results require team action.
