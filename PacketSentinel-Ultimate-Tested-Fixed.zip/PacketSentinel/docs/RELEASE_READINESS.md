# Release readiness — October 29, 2026

## Changes in this edition

- Expanded bounded DNS QNAME parsing to the RFC wire maximum (255 bytes); compression pointers remain intentionally rejected.
- Reversed the token reservation order: global capacity is reserved first, with a capped refund if per-source capacity denies the packet. This avoids permanent global-token loss for source-denied packets, but concurrent refunds/refills may cause transient conservative behavior.
- Added read-only mode verification per experiment trial (`tools/verify_mode.py`). It checks whether any XDP program appears attached and whether the PacketSentinel nftables table exists. **It cannot establish that the attached program is PacketSentinel itself.** Manually verify program identity with `bpftool prog show`.
- Improved DNS probe response peer checking and DNS label validation.
- Expanded Python tests.

## Explicit design limits

- IPv4, UDP destination port 53 only. IPv6, DNS-over-TCP, noninitial IP fragments and stacked VLAN tags beyond two are outside the filtering path. Do not expose the responder to public networks.
- IPv4 fragments are passed. Malformed non-DNS framing is also generally passed rather than dropped. Some invalid DNS questions are dropped. This is a lab policy, not a comprehensive firewall.
- LRU source buckets may be evicted when more than 16,384 source IP keys are active. Synthetic source spoofing is not detected.
- Unexpected configuration/map failures fail open and increment `map_failure`; treat **any nonzero map_failure** as a failure of the experiment. A production deployment may prefer fail-closed, monitored and provisioned appropriately.
- Kernel/XDP verifier acceptance and C compilation are NOT established by the Python suite. These require Ubuntu/Linux lab verification.
- Native-mode XDP CPU savings cannot be inferred from generic-mode runs; document actual mode.
- CPU occupancy from /proc/stat is host-wide. NIC hardware counters, UDP socket receive drops, softirq CPU utilization and load-generator overhead are not comprehensively captured.
- The legitimate probe and load generator can share source IP; per-IP limiting may affect the legitimate probe disproportionately. Ideally use separate source IPv4 addresses and document them.
- Bursty and ramp synthetic patterns have different time-varying offered traffic; do not treat equal configured PPS as equal actual packets.
- The nftables baseline's UDP header matching and XDP's DNS question parsing differ by design. This is a comparison of firewall mechanisms under the same offered packets, **not** strict semantic equivalence.

## Required manual sign-off

1. Build with `make CLANG=/usr/bin/clang` on Host B; save warnings and verifier output.
2. Ensure `bpffs` is mounted at `/sys/fs/bpf`, and no preexisting XDP attachment will be replaced.
3. Attach once using native and/or generic mode, verify with `ip -details link show dev IFACE` and `bpftool prog show`.
4. Run `packetctl stats` to check pass/drop counters on actual wire packets, then detach and confirm map pin cleanup.
5. For each mode: verify correct mode, snapshot lab settings, use ≥3 repeats, retain JSON and CSV, identify receiver kernel/NIC/CPU topology.
6. Run positive, negative, VLAN, malformed, IPv4 fragment, idle-refill, per-source/global limit, and map-pressure tests in isolated namespaces or a dedicated lab.
7. Complete the report with real measurements and use the organizer-supplied PDF structure; do not invent graphs or measurements.
8. Review ownership transfer request before handing the repository to organizers.
