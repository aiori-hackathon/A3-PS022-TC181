# AIORI PS-022 submission checklist

- [ ] Private GitHub repository uses the **actual team name**.
- [ ] All team members have access.
- [ ] AIORI organizer `aiori-hackathon` is invited as collaborator; ownership is transferred only after following official organizer directions and coordinating with team members.
- [ ] PDF follows organizer's `Proposed-structure-hackathon.pdf` (not supplied in the reference files).
- [ ] Demonstrate the prototype and show pseudocode to a mentor.
- [ ] Two controlled Linux hosts, or documented XDP-generic-mode constraints.
- [ ] CPU, traffic throughput, drop counters and legitimate DNS success are measured for no-filter, nftables, and XDP across three patterns.
- [ ] Include actual results, repeated-trial variations, setup details, and a discussion of false positives and limitations.
- [ ] Keep demonstration isolated; never send synthetic floods to public services.
