# Local verification record

Date: 2026-10-29

## Executed in this review container

- ZIP integrity check and extraction: passed (34 archive entries; no corrupt member).
- `python3 -m unittest discover -s tests -v`: **16 tests passed** after the change below.
- `python3 -m compileall -q tools tests`: passed.
- `bash -n tools/nft_mode.sh`: passed.
- CLI safety smoke test: public target `8.8.8.8` rejected with exit code 2.
- CLI safety smoke test: load rate of 2,001 queries/s rejected with exit code 2.
- DNS responder UDP loopback integration test: passed as part of the unit suite.

## Change made in this review

- `tools/summarize.py`: malformed/non-numeric, `NaN`, and infinite metric values are now skipped instead of raising an exception while summarizing. This handles empty probe latency values when all probes fail.
- `tests/test_results.py`: added a regression test covering `None`-style latency, empty fields, `NaN`, and infinity.

## Build and environment limitations

- `make all`: **blocked** because the environment lacks `bpf/bpf_helpers.h` and libbpf development files. The failure occurred compiling `src/xdp_dns.c`; the userspace `packetctl` binary therefore was not built.
- No BPF verifier load, XDP attach/detach, actual nftables validation, or two-host traffic/performance experiment was run. This environment cannot establish kernel/NIC compatibility or performance claims.
- Python startup emits an unrelated spreadsheet-runtime warmup traceback in this execution environment; the test process still exits successfully and all 16 tests pass.

The test results establish Python behavior and syntax/safety checks only. They do not establish eBPF compilation, kernel compatibility, or measured mitigation effectiveness.
