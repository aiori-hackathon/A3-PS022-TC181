# Code audit — October 29, 2026

## Findings fixed in this revision

| ID | Severity | Finding | Revision |
|---|---|---|---|
| A1 | High | A >1-second idle interval was capped to a 1-second refill, leaving a bucket unexpectedly short of tokens. | Use bounded, saturation-safe refill that fills to capacity when sufficient time has elapsed. |
| A2 | High | Map-pinning failures could leave maps pinned after an XDP attach rollback. | Unpin previously pinned maps and remove the created directory on failure. |
| A3 | High | Failed XDP detach previously removed pinned maps anyway, obscuring recovery. | Preserve pins when the kernel detach operation fails. |
| A4 | Medium | Unknown XDP modes were implicitly treated as native. | Reject unsupported attach/detach modes. |
| A5 | Medium | DNS query ID, non-ASCII labels and total query name size were not validated properly. | Validate before encoding; add regression tests. |
| A6 | Medium | Lab DNS server originally defaulted to binding all interfaces. | Require explicit bind address; permit loopback only for non-53 unit tests. |
| A7 | Medium | The parser did not enforce IPv4 total-length and UDP datagram-length consistency. | Add both bounds checks before DNS parsing. |

## Verified locally

- Python unit tests: 15/15 pass in the 2026-10-29 review run, including UDP loopback and XDP snapshot-validation regression tests.
- Python tools: `python3 -m compileall -q tools` succeeded.
- Inspected repository for artifact layout and safety caps.

## Not yet verified (do not claim success)

- Compilation with a Clang BPF target and libbpf development headers. This container does not have a suitable BPF/libbpf toolchain.
- Linux BPF verifier acceptance, `bpf_spin_lock` compatibility with target kernel and NIC native/generic attachment.
- nftables syntax and rule execution on the chosen Ubuntu release.
- Actual per-source/global enforcement under simultaneous lab traffic, map pressure, VLAN/IPv6/fragment behavior and teardown/restart tests.
- CPU, packet throughput, legitimate-query success and real packet-drop comparisons.
- Exact matching to the organizer's separately named PDF template, which was not uploaded.

## Important remaining technical limitations

1. The XDP classifier parses Ethernet with up to two VLAN tags and matches IPv4 UDP destination port 53. Other protocols, more than two VLAN tags, fragments and IPv6 bypass rate limiting. This is a scoped lab demonstration, not a complete DNS firewall.
2. Per-source tokens are consumed before a global denial. This policy can penalize an otherwise compliant source; the design should be revised if strict fairness is required.
3. A single spinlock-protected global bucket may contend on multicore workloads. Test at actual intended load; per-CPU allocations would change global semantics.
4. Map lookup or configuration failure currently fails open by design. A production system needs an explicit threat-model-driven decision and alerting.
5. The 255-byte QNAME wire cap and rejection of first-name compression intentionally reject some otherwise-valid DNS queries; first-name compression and more complete DNS semantics are not implemented.
6. Metrics are not automated end-to-end across two hosts. The sender and receiver measurements must be time-aligned; nftables drop counters should be recorded separately.
7. No kernel-level XDP unit/integration test or traffic replay was performed in this environment.

## Required final validation

1. Build on Ubuntu Linux with the full documented clang/libbpf toolchain.
2. Attach native XDP or record fallback to generic mode and BPF verifier logs.
3. Validate nftables rules on target Host B.
4. For each of three modes and three patterns, collect at least three repeated real runs with independent source traffic and concurrent legitimate queries.
5. Capture raw counters and report medians/variance, with no synthetic performance values represented as observed results.
6. Update technical report to official organizer layout and include actual screenshots and logs.
