import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'tools' / 'compare.py'

class CompareCliTests(unittest.TestCase):
    def invoke(self, mode, extra=()):
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            payloads = {
                'load': {'achieved_pps': 10, 'sent': 20},
                'probe': {'success_pct': 100, 'success': 30, 'sent': 30, 'avg_latency_ms': 1},
                'metrics': {'cpu_busy_pct': 2, 'rx_dropped_delta': 0},
                'before': {'drop_source': 0, 'drop_global': 0, 'drop_malformed': 0},
                'after': {'drop_source': 1, 'drop_global': 0, 'drop_malformed': 0},
            }
            paths = {}
            for name, value in payloads.items():
                paths[name] = d / f'{name}.json'
                paths[name].write_text(json.dumps(value))
            cmd = [sys.executable, str(SCRIPT), '--mode', mode, '--pattern', 'steady',
                   '--load', str(paths['load']), '--probe', str(paths['probe']),
                   '--metrics', str(paths['metrics']), '--output', str(d / 'out.csv'), *extra]
            return subprocess.run(cmd, capture_output=True, text=True)

    def test_xdp_requires_both_snapshots(self):
        r = self.invoke('xdp')
        self.assertNotEqual(r.returncode, 0)
        self.assertIn('requires both', r.stderr)

    def test_non_xdp_rejects_after_only(self):
        with tempfile.TemporaryDirectory() as td:
            snap = Path(td) / 'after.json'
            snap.write_text('{}')
            r = self.invoke('none', ('--xdp-after', str(snap),))
        self.assertNotEqual(r.returncode, 0)

    def test_xdp_accepts_both_snapshots(self):
        with tempfile.TemporaryDirectory() as td:
            before = Path(td) / 'before.json'; after = Path(td) / 'after.json'
            before.write_text(json.dumps({'drop_source': 0, 'drop_global': 0, 'drop_malformed': 0}))
            after.write_text(json.dumps({'drop_source': 1, 'drop_global': 2, 'drop_malformed': 0}))
            r = self.invoke('xdp', ('--xdp-before', str(before), '--xdp-after', str(after)))
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('"xdp_drop_delta": 3', r.stdout)

if __name__ == '__main__':
    unittest.main()
