import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from verify_mode import check_mode

class ModeTests(unittest.TestCase):
    def test_none(self):
        self.assertTrue(check_mode('none', False, False))
        self.assertFalse(check_mode('none', True, False))
        self.assertFalse(check_mode('none', False, True))
    def test_nft(self):
        self.assertTrue(check_mode('nftables', False, True))
        self.assertFalse(check_mode('nftables', True, True))
    def test_xdp(self):
        self.assertTrue(check_mode('xdp', True, False))
        self.assertFalse(check_mode('xdp', False, False))
        self.assertFalse(check_mode('xdp', True, True))
