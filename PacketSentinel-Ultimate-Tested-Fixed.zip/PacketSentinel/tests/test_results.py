import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('plot_results', ROOT/'tools/plot_results.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class ResultTests(unittest.TestCase):
    def test_aggregation(self):
        rows = [dict(pattern='steady', mode='xdp', cpu_busy_pct='10'), dict(pattern='steady', mode='xdp', cpu_busy_pct='20'), dict(pattern='ramp', mode='none', cpu_busy_pct='')]
        result = module.aggregate(rows, 'cpu_busy_pct')
        self.assertEqual(result[('steady','xdp')], 15)
        self.assertNotIn(('ramp','none'), result)
    def test_invalid_metrics_skipped(self):
        self.assertEqual(module.aggregate([dict(pattern='bursty', mode='none')], 'success_pct'), {})

    def test_summarize_skips_null_and_non_numeric_metrics(self):
        import importlib.util
        spec2 = importlib.util.spec_from_file_location('summarize', ROOT/'tools/summarize.py')
        summarize = importlib.util.module_from_spec(spec2)
        spec2.loader.exec_module(summarize)
        rows = [
            {'mode': 'none', 'pattern': 'steady', 'success_pct': '100', 'avg_latency_ms': 'None'},
            {'mode': 'none', 'pattern': 'steady', 'success_pct': '', 'avg_latency_ms': ''},
            {'mode': 'none', 'pattern': 'steady', 'success_pct': 'nan', 'avg_latency_ms': 'inf'},
        ]
        result = summarize.summarize(rows)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['metric'], 'success_pct')
        self.assertEqual(result[0]['mean'], 100.0)
