import importlib.util
import pathlib
import socket
import struct
import threading
import time
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('dns_lab',ROOT/'tools/dns_lab.py')
lab=importlib.util.module_from_spec(spec);spec.loader.exec_module(lab)

class TestLab(unittest.TestCase):
 def test_packet(self):
  q=lab.encode_query(1234)
  self.assertEqual(struct.unpack('!H',q[:2])[0],1234)
  self.assertEqual(struct.unpack('!H',q[4:6])[0],1)
  self.assertTrue(q.endswith(b'\x00\x01\x00\x01'))
 def test_target_scope(self):
  for a in ['10.0.0.5','172.16.8.2','192.168.56.20']:self.assertEqual(lab.private_target(a),a)
  for a in ['127.0.0.1','8.8.8.8','169.254.2.3','224.0.0.1','::1']:
   with self.assertRaises(ValueError):lab.private_target(a)
 def test_query_validation(self):
  with self.assertRaises(ValueError):lab.encode_query(2,'x'*64+'.test')
 def test_bad_queries(self):
  for qid in (-1,65536):
   with self.assertRaises(ValueError): lab.encode_query(qid)
  with self.assertRaises(ValueError): lab.encode_query(1,'café.test')
  with self.assertRaises(ValueError): lab.encode_query(1,'a'*63+'.'+'b'*63+'.'+'c'*63+'.'+'d'*63)
 def test_responder(self):
  stop=threading.Event()
  # Port >1024 only for unit testing; production lab listens on UDP 53.
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
   s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  t=threading.Thread(target=lab.server,args=('127.0.0.1',port,stop),daemon=True);t.start();time.sleep(.1)
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
   s.settimeout(1);s.sendto(lab.encode_query(412),('127.0.0.1',port));r,_=s.recvfrom(1000)
  self.assertEqual(r[:2],struct.pack('!H',412));self.assertTrue(r[2]&0x80)
  stop.set();t.join(1)
if __name__=='__main__':unittest.main()

class AdditionalValidation(unittest.TestCase):
 def test_query_control_bytes(self):
  for name in ('bad name.test', 'bad\x00name.test', '.example', 'example.'):
   with self.assertRaises(ValueError):lab.encode_query(1,name)
 def test_private_ranges(self):
  for ip in ('172.15.0.1','172.32.0.1','198.18.0.1','192.0.2.1','255.255.255.255'):
   with self.assertRaises(ValueError):lab.private_target(ip)
